#!/bin/bash

cur_dir=$(cd `dirname $0`;pwd)
cd $cur_dir
port=7004
pass=123456

source $cur_dir/bin/common.sh

$redis_cli -p $port -a $pass $1
