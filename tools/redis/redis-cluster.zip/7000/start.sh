#!/bin/bash

cur_dir=$(cd `dirname $0`;pwd)
cd $cur_dir
source $cur_dir/bin/common.sh
$redis_server $cur_dir/conf/redis.conf
