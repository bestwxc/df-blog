#!/bin/bash

cur_dir=$(cd `dirname $0`;pwd)
cd $cur_dir

redis_home=/opt/software/redis
redis_cli=$redis_home/bin/redis-cli

$redis_cli --cluster create -a 123456 \
 172.18.16.237:7000 172.18.16.237:7001 \
 172.18.16.237:7002 172.18.16.237:7003 \
 172.18.16.237:7004 172.18.16.237:7005 \
 --cluster-replicas 1
