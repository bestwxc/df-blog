#!/bin/bash

cur_dir=$(cd `dirname $0`;pwd)

find "$cur_dir" -name "stop.sh" -exec bash {} \;
