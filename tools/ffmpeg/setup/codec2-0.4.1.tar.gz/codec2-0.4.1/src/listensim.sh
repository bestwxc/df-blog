#!/bin/sh
# listensim.sh
# David Rowe 10 Sep 2009
#
# Listen to files processed with sim.sh

../script/menu.sh $1_uq.raw $1_lpc10.raw $1_lpcpf.raw $1_phase0.raw $1_phase0_lpcpf.raw $2 $3 $4 $5


