/*
 * Dummy function to avoid compiler error
 */
void _init() {

}
void _fini() {

}

